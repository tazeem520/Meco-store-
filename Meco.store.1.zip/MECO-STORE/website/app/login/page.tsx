import {redirect} from 'next/navigation';export default function Login(){redirect('/login-form.html')}
