import Catalog from '@/components/Catalog';export default function Games(){return <Catalog game/>}
