import Catalog from '@/components/Catalog';export default function Apps(){return <Catalog game={false}/>}
