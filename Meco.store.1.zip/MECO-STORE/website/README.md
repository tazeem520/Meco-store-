# MECO STORE Website

Next.js + TypeScript + Tailwind storefront, interactive lamp login, Supabase accounts, secure APK downloads and protected admin publishing.

## Local setup

```sh
cp .env.example .env.local
npm install
npm run dev
```

Apply `../backend/database/migrations/202611070001_initial.sql` in Supabase and deploy `scan-upload`. The unconfigured preview uses clearly marked sample cards with no download buttons. Once configured, only real published apps appear.

## Deploy to Vercel

Import the `website` directory, set all `.env.example` variables, and deploy with build command `npm run build`. Add the Vercel domain to Supabase Auth redirect URLs. Keep the service-role key server-only. Configure the malware scanner before publishing APKs.

Verified: `npm run build` succeeds.
