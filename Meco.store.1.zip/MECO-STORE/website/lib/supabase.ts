import {createBrowserClient,createServerClient} from '@supabase/ssr';
import {createClient as createAdminClient} from '@supabase/supabase-js';
import {cookies} from 'next/headers';
export const hasSupabase=!!(process.env.NEXT_PUBLIC_SUPABASE_URL&&process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
export async function createClient(){const store=await cookies();return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{cookies:{getAll:()=>store.getAll(),setAll:(items:{name:string;value:string;options:any}[])=>items.forEach(({name,value,options})=>{try{store.set(name,value,options)}catch{}})}})}
export function browserClient(){return createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)}
export function serviceClient(){if(!process.env.SUPABASE_SERVICE_ROLE_KEY)throw new Error('Server configuration missing');return createAdminClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.SUPABASE_SERVICE_ROLE_KEY!,{auth:{persistSession:false}})}
export async function requireAdmin(){const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)throw new Error('Unauthorized');const {data}=await supabase.from('admin_roles').select('role').eq('user_id',user.id).maybeSingle();if(!data)throw new Error('Forbidden');return {supabase,user}}
