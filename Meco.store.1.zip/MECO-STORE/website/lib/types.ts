export type Category={id:string;name:string;slug:string;kind:'game'|'app'};
export type AppItem={id:string;slug:string;name:string;developer:string;short_description:string;description:string;icon_url:string;category_id:string;is_game:boolean;is_featured:boolean;is_sample:boolean;download_count:number;rating_average:number;rating_count:number;updated_at:string;categories?:Category;app_versions?:AppVersion[];screenshots?:{id:string;image_url:string;alt_text:string}[]};
export type AppVersion={id:string;version:string;size_bytes:number;sha256:string;permissions:string[];changelog:string;scan_status:string;released_at:string;storage_path:string};
export const formatBytes=(n:number)=>n?`${(n/1024/1024).toFixed(1)} MB`:'Not published';
export const formatCount=(n:number)=>new Intl.NumberFormat('en',{notation:'compact',maximumFractionDigits:1}).format(n);
