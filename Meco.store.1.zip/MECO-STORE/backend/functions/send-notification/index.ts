// Optional webhook target: send FCM/APNs using a server-side provider; never expose provider keys to clients.
Deno.serve(async req=>{if(req.headers.get('x-webhook-secret')!==Deno.env.get('WEBHOOK_SECRET'))return new Response('Unauthorized',{status:401});const event=await req.json();console.log('Queue notification',event.type,event.record?.id);return Response.json({queued:true})});
