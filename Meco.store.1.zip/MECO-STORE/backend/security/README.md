# Security operations

- Configure `CLAMAV_URL` to an isolated scanner exposing `POST /scan`; return JSON `{clean:boolean,engine:string,result:string}`. Require `CLAMAV_TOKEN` at the scanner.
- Treat `clean` as necessary, not sufficient. Before production, add Android signature parsing with `apksigner verify --print-certs`, store `signature_sha256`, and enforce the same signer on updates.
- Add Vercel/Upstash distributed rate limiting; the included in-memory download limiter is only a development safeguard.
- Rotate service-role keys, enable Supabase MFA for admins, configure CAPTCHA on sign-up, set Auth redirect URLs, and review Postgres logs.
- Keep all APKs private. Downloads use 120-second signed URLs. Backups and logs must not contain signed links.
- Run `supabase db lint`, dependency audits, RLS integration tests, malicious-file tests and storage access tests before launch.
