# MECO STORE

Real-app Android marketplace with a Next.js website, Expo Android source and Supabase backend. No dummy, bot or sample apps are shown.

## Folders

- `website/` — Next.js storefront, lamp login and admin dashboard
- `android-app/` — Expo React Native Android application
- `backend/` — Supabase SQL migration and Edge Functions

## Website on Render

- Root directory: `website`
- Build command: `npm install && npm run build`
- Start command: `npm run start`

Set `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and server-only `SUPABASE_SERVICE_ROLE_KEY` in Render Environment Variables.

## Database

Apply `backend/database/migrations/202611070001_initial.sql` once in a fresh Supabase project. Do not commit `.env`, `.env.local`, APKs, `node_modules`, or production secrets.
