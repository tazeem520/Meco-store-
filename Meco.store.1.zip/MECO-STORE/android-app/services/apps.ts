import {supabase,authConfigured} from './supabase';
export type StoreApp={id:string;slug:string;name:string;developer:string;short_description:string;description:string;icon_url:string;is_game:boolean;download_count:number;rating_average:number;updated_at:string;app_versions?:Release[]};
export type Release={id:string;version:string;size_bytes:number;sha256:string;permissions:string[];scan_status:string;released_at:string};
export async function fetchApps(game?:boolean){if(!authConfigured)return[];let q=supabase.from('apps').select('*,app_versions(*)').eq('status','published').order('updated_at',{ascending:false});if(game!==undefined)q=q.eq('is_game',game);const {data,error}=await q;if(error)throw error;return(data||[])as StoreApp[]}
export async function fetchApp(slug:string){if(!authConfigured)return null;const {data,error}=await supabase.from('apps').select('*,app_versions(*)').eq('slug',slug).eq('status','published').maybeSingle();if(error)throw error;return data as StoreApp|null}
