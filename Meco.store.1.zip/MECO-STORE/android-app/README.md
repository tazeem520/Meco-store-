# MECO STORE Android

Expo + React Native + TypeScript application with an interactive lamp login, Supabase Auth, live published-app catalog, search, app details, resumable APK downloads, SHA-256 verification, local history and Android's user-confirmed package installer.

## Run on a phone

1. Install Node 20 and dependencies:
   ```sh
   npm install
   cp .env.example .env
   ```
2. Set your Supabase URL and **public anon key**, plus the deployed website API URL. Never place `SUPABASE_SERVICE_ROLE_KEY` in this app.
3. Install Expo Go on Android and run `npm start`. Scan the QR code on the same network. APK installation requires a development/production build, not Expo Go.
4. With no Supabase configuration, sign-in and catalog correctly report setup requirements; the app does not show fake apps or downloads.

## Build an installable APK

1. Create an Expo account, install EAS (`npm i -g eas-cli`) and run `eas login`.
2. Run `eas init` and replace `REPLACE_WITH_EAS_PROJECT_ID` in `app.json` with the generated ID.
3. Configure `.env` values in EAS Secrets or `eas.json`; public values are embedded in the client bundle.
4. Run `npm run build:apk`. Download the resulting APK from the Expo build page.
5. Android will ask for unknown-app installation permission where required. Review the official installer prompt; the app never silently installs packages.

## Verify

```sh
npm run typecheck
npx expo export --platform android
npx expo-doctor
```

The Android export and TypeScript check have both passed in this workspace. For backend setup, apply `../backend/database/migrations/202611070001_initial.sql`, deploy the scan function, configure ClamAV, and deploy `../website`. Only clean, published releases receive signed download URLs.
